import { BehaviorSubject } from 'rxjs';

const subject = new BehaviorSubject(false);

const subjectService = {
    loaderMessage : (message) =>  subject.next({message: message}),
    getMessage : () => subject.asObservable()
} 

export { subjectService, subject}