import React from 'react';
import { Route, Switch, Redirect } from 'react-router';
import AdminDashboard from './container/AdminPage/AdminDashboard/admindashboard';
import Dashboard from './container/Dashboard/dashboard'

const Routes = () => {
    return(
        <Switch>
        <Route exact path="/" >
        <Redirect to = '/login-register'/>
        </Route>
        <Route exact path='/login-register' component={Dashboard}/>
        <Route exact path='/home/dashboard' component={AdminDashboard}/>
        <Route component = {()=> {
            return <div> No Path Found </div>
        }
        }/>
        </Switch>
    )
}

export default Routes;