export default class environment{
    static myInstance = null;
    domainUrl = 'http://localhost:3000';
    static getInstance(){
        if(environment.myInstance === null){
            environment.myInstance = new environment();
        }
        return this.myInstance;
    }

    getApi = () => {
        const api = {
             loginApi : this.domainUrl + '/api/effy/users/login',
             registerApi: this.domainUrl + '/api/effy/users/register',
             getUsers: this.domainUrl + '/api/effy/users/listUsers',
             getUserById: this.domainUrl + '/api/effy/users/getUser/',
             updateUser: this.domainUrl + '/api/effy/users/updateUser',
             deactivateUser: this.domainUrl + '/api/effy/users/deactivateUser',
             deleteUser: this.domainUrl + '/api/effy/users/deleteUser',
             getUserCompany: this.domainUrl + '/api/effy/users/getUserCompany',
             getUserByCompanyId: this.domainUrl + '/api/effy/users/getUserByCompanyId',
             removeUserCompany: this.domainUrl + '/api/effy/users/removeUserCompany',
             getCompanies: this.domainUrl + '/api/effy/company/getCompanies',
             saveCompany: this.domainUrl + '/api/effy/company/saveCompany',
             getCompanyById: this.domainUrl + '/api/effy/company/getCompany',
             updateCompany: this.domainUrl + '/api/effy/company/updateCompany',
             deleteCompany: this.domainUrl + '/api/effy/company/deleteCompany'
        }
        return api;
    }
}