import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './container/App/App';
import registerServiceWorker from './registerServiceWorker';
import { BrowserRouter } from 'react-router-dom';
import axios from 'axios';
import { subjectService } from './services/subject-service';

axios.interceptors.request.use(request => {
    subjectService.loaderMessage(true);
    if(localStorage.getItem('token')){    
        request.headers.Authorization = 'Bearer ' + localStorage.getItem('token');
    }
    return request;
}, error => {
    subjectService.loaderMessage(false);
    return Promise.reject(error);
})

axios.interceptors.response.use(response => {
    subjectService.loaderMessage(false);
    return response;
}, error => {
    alert(error.response.data.err.status !== 422 ? error.response.data.err.message: error.response.data.err.details[0].message);
    if(error.response.data.err.message === 'jwt expired'){
        window.location.href = ""
    }
    subjectService.loaderMessage(false);
    return Promise.reject(error);
})

ReactDOM.render(<BrowserRouter><App/></BrowserRouter>, document.getElementById('root'));
registerServiceWorker();
/* Component lifecycle */

/* 
componentWillMount() -- initial time first calling method
render()
componentDidMount() --initial time last calling method [place to call api]

componentWillReceiveProps(nextProps) -- Whenever a component receives a new set of props, this method will be called first
You can set the state by using this.setState()

shouldComponentUpdate(nextState, nextProps)
You can’t call setState here. Also, it wouldn’t make much sense to do so. 
If you want to set the state because of changing props, use componentWillReceiveProps instead.

componentWillUpdate(nextProps, nextState)
You can’t call setState here. Again, if you want to set the state because of changing props, use componentWillReceiveProps instead.

componentDidUpdate(prevProps, prevState)
You can use setState here.

A good example for this would be the update of a 3rd party UI library like D3 to pass on the new data.

componentWillUnmount()
Right before React unmounts and destroys our component, it invokes componentWillUnmount.

*/