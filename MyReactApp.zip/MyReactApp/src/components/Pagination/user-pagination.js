import React, { useEffect, useState } from 'react';
import PaginationNumbers from './Pagination-rows/pagination-numbers/pagination-numbers';
import axios from 'axios';
import './user-pagination.css';
import environment from '../../environment';
const environmentService = new environment();

const UserPagination = (props) => {
    const length = props.users.length;
    const [posts, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage] = useState(5);
    
    useEffect(() => {
        const indexOfLastPost = currentPage * postsPerPage;
        const indexOfFirstPost = indexOfLastPost - postsPerPage;
        const currentPost = [...props.users].slice(indexOfFirstPost, indexOfLastPost);
        setPosts(currentPost);
    },[props.users]);

    const changePost = (pageNumber) => {
        setCurrentPage(pageNumber);
    }

    useEffect(() => {
        const indexOfLastPost = currentPage * postsPerPage;
        const indexOfFirstPost = indexOfLastPost - postsPerPage;
        const currentPost = [...props.users].slice(indexOfFirstPost, indexOfLastPost);
        setPosts(currentPost);
    },[currentPage])

    const deleteUser = (id) => {
        if(window.confirm('Are you sure want to delete')){
            axios.delete(environmentService.getApi().deleteUser , {params: {id: id}})
            .then(success => {
                console.log(success);
                props.update()
            })
        }
    }

    const deactivateUser = (id, active) => {
        if(window.confirm(`Are you sure want to ${active === 1 ? 'deactivate' : 'activate'}`)){
            axios.put(environmentService.getApi().deactivateUser, { id: id, active: !active} )
            .then(success => {
                console.log(success);
                props.update();
            })
        }
    }
    
    return(
        <div className="pagination">
            <h1>Users</h1>
            <table id="users">
                <tr>
                    <th>FirstName</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Designation</th>
                    <th>Edit</th>
                    <th>Delete</th>
                    <th>Active/Deactive</th>
                </tr>
                {
                    [...posts].map(data => {
                        return(
                        <tr key={data.id} >
                            <td className={data.active === 0 ? 'add-opacity': null}>{data.firstName}</td>
                            <td className={data.active === 0 ? 'add-opacity': null}>{data.email}</td>
                            <td className={data.active === 0 ? 'add-opacity': null}>{data.companyName}</td>
                            <td className={data.active === 0 ? 'add-opacity': null}>{data.designation}</td>
                            <td className={data.active === 0 ? 'add-opacity': null}><i className="fa fa-edit" onClick={() => data.active === 1 ? props.openPopUp(data): alert('Unable to edit')}></i></td>
                            <td><i className="fa fa-trash" onClick={() => deleteUser(data.id)} style={{paddingBottom:"2px"}}></i></td>
                            <td>
                                <i className="fa fa-ban" onClick={() => deactivateUser(data.id, data.active)}></i></td>
                        </tr>
                        )
                    })
                }
            </table>
            <PaginationNumbers postsPerPage={postsPerPage} totalPosts={length} changePost = {changePost}/> 
        </div>
    )
}

export default UserPagination;