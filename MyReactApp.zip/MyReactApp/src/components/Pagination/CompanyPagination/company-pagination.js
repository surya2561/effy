import React, { useEffect, useState } from 'react';
import PaginationNumbers from '../Pagination-rows/pagination-numbers/pagination-numbers';
import './company-pagination.css';
import axios from 'axios';
import environment from '../../../environment';
const environmentService = new environment();

const CompanyPagination = (props) => {
    const length = props.company.length;
    const [posts, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage] = useState(5);
       
    useEffect(() => {
        console.log(props.company);
        const indexOfLastPost = currentPage * postsPerPage;
        const indexOfFirstPost = indexOfLastPost - postsPerPage;
        const currentPost = [...props.company].slice(indexOfFirstPost, indexOfLastPost);
        setPosts(currentPost);
    },[props.company]);

    const changePost = (pageNumber) => {
        setCurrentPage(pageNumber);
    }

    useEffect(() => {
        const indexOfLastPost = currentPage * postsPerPage;
        const indexOfFirstPost = indexOfLastPost - postsPerPage;
        const currentPost = [...props.company].slice(indexOfFirstPost, indexOfLastPost);
        setPosts(currentPost);
    },[currentPage])

    const deleteCompany = (id) => {
        if(window.confirm('Are you sure want to delete')){
            axios.delete(environmentService.getApi().deleteCompany, {params: {id: id}})
            .then(success => {
                props.update()
            })
        }
    }

    return(
        <div class="company-pagination">
            <h1>Company</h1>
            <table id="company">
                <tr>
                    <th>CompanyName</th>
                    <th>CompanyAddress</th>
                    <th>Users</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                {
                    [...posts].map(data => {
                        return(
                        <tr key={data.id} >
                            <td>{data.companyName}</td>
                            <td onClick={() => { props.openMap(data)}} className="address">{data.companyAddress}</td>
                            <td >{data.user_count}</td>
                            <td><i className="fa fa-edit" onClick={() => props.openPopUp(data)}></i></td>
                            <td><i className="fa fa-trash" onClick={() => deleteCompany(data.id)}></i></td>
                            {/* <td><i className="fa fa-user" onClick={() => deactivate(data.id, data.active)}></i></td> */}
                        </tr>
                        )
                    })
                }
            </table>
            <PaginationNumbers postsPerPage={postsPerPage} totalPosts={length} changePost = {changePost}/> 

        </div>
    )
}

export default CompanyPagination;