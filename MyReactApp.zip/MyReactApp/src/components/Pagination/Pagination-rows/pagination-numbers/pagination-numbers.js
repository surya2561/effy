import { datePickerDefaultProps } from '@material-ui/pickers/constants/prop-types';
import React, { useEffect, useState } from 'react';
import './pagination-numbers.css';
const PaginationNumbers = ({postsPerPage, totalPosts, changePost}) =>{
    const [pageNumbers, setPageNumbers] = useState([]);
    useEffect(() => {
        pageNumbers.length = 0;
        for(let i = 1; i <= Math.ceil(totalPosts/postsPerPage); i++){
             pageNumbers.push(i);
        }
        setPageNumbers(pageNumbers);
    })
    return(
        <div>
            <ul className="numbers">
                <li className="arrows">&laquo;</li>
                {[...pageNumbers].map((number, i) => {
                    return(
                    <li key={i} className="page-item">
                        <a className="page-link" onClick={() => { changePost(number)}}>
                            {number}
                        </a>
                    </li>
                    )
                })}
                 <li className="arrows">&raquo;</li>
            </ul>
        </div>
    )
}
export default PaginationNumbers;
