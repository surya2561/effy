import React, { useEffect, useState } from 'react';
import PaginationNumbers from '../Pagination-rows/pagination-numbers/pagination-numbers';
import './productPagination.css';
const ProductPagination = (props) => {
    const length = props.product.length;
    const [data, setData] = useState([]);
    const [posts, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [postsPerPage] = useState(2);

    useEffect(() => {
        changePostData(props.product);
        setData(props.product);
    },[props.product]);

    const changePost = (pageNumber) => {
        setCurrentPage(pageNumber);
    }

    useEffect(() => {
        changePostData(props.product);
    },[currentPage])

    const changePostData = (value) =>{
        const indexOfLastPost = currentPage * postsPerPage;
        const indexOfFirstPost = indexOfLastPost - postsPerPage;
        const currentPost = [...value].slice(indexOfFirstPost, indexOfLastPost);
        setPosts(currentPost);
    }
    const sortByCategory = (type) =>{
        const value = data;
        value.sort(function(a, b){
            if(type === 'product'){
                if(a.P_name < b.P_name) { return -1; }
                if(a.P_name > b.P_name) { return 1; }
            }
            else if(type === 'user'){
                if(a.name < b.name) { return -1; }
                if(a.name > b.name) { return 1; }
            }
            else if(type === 'email'){
                if(a.email < b.email) { return -1; }
                if(a.email > b.email) { return 1; }
            }
            else{
                if(a.C_name < b.C_name) { return -1; }
                if(a.C_name > b.C_name) { return 1; }
            
            }
            return 0;
        })
        changePostData(value);
    }

    return (
        <div class="product-pagination">
            <h1>product</h1>
            <table id="product">
                <tr>
                    <th onClick={() => sortByCategory('product')}>ProductName</th>
                    <th onClick={() => sortByCategory('user')}>UserName</th>
                    <th onClick={() => sortByCategory('email')}>UserEmail</th>
                    <th onClick={() => sortByCategory('category')}>CategoryName</th>
                </tr>
                {
                    [...posts].map(data => {
                        return(
                        <tr key={data.id} >
                            <td>{data.P_name}</td>
                            <td>{data.name}</td>
                            <td>{data.email}</td>
                            <td >{data.C_name}</td>
                        </tr>
                        )
                    })
                }
            </table>
            <PaginationNumbers postsPerPage={postsPerPage} totalPosts={length} changePost = {changePost}/> 

        </div>
    )
}

export default ProductPagination;

