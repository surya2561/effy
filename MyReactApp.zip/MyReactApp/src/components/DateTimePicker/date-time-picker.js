import 'date-fns';
import React from 'react';
import './date-time-picker.css';
import Grid from '@material-ui/core/Grid';
import DateFnsUtils from '@date-io/date-fns';
import {
  MuiPickersUtilsProvider,
  KeyboardDateTimePicker,
  KeyboardDatePicker
} from '@material-ui/pickers';

export default function MaterialUIPickers(props) {
  const [selectedDate, setSelectedDate] = React.useState(props.value || new Date());
  return (
    props.name !== 'DateOfBirth' ?
    <MuiPickersUtilsProvider utils={DateFnsUtils}>
      <Grid container justify="space-around">
       <KeyboardDateTimePicker
        label={props.label}
        value={props.date}
        disablePast= {true}
        minDate={props.label === 'startDate' ? null : props.date}
        onChange={date => { props.change(date)}}
      />
      </Grid>
    </MuiPickersUtilsProvider> :

   <MuiPickersUtilsProvider utils={DateFnsUtils}>
     <Grid container justify="space-around">
      <KeyboardDatePicker
       label={props.label}
       value={selectedDate}
       disableFuture="false"  
       format="MM/dd/yyyy"
       onChange={date => { setSelectedDate(date); props.inputChangeHandler(date)}}
     />
     </Grid>
   </MuiPickersUtilsProvider>
  
  );
}