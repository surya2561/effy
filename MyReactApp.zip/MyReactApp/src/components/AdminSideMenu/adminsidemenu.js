import React, { useEffect, useState } from 'react';
import './adminsidemenu.css';

const AdminSideMenu = (props) => {
    const list = [
        { 
            icon: 'fa-home',
            name: "Home",
            active: 'active',
            sub_name: 'Home',
            sub_courses: [
            ]
        },
        { 
            icon: 'fa-database',
            name:"Manage Company", 
            active: null,
            sub_name: 'Company', 
            sub_courses: [
            { name: 'Add Company' },
            { name: 'Manage Company' }
          ]
        },
        { 
            icon: 'fa-user',
            name: "Manage User", 
            active: null,
            sub_name: 'User', 
            sub_courses: [
            { name: 'Add User' },
            { name: 'Manage User'}
          ]
        },
    ];
    const [lists, setLists] = useState(list);

    const showSubMenu = (index) => {
        let name;
        [...list].map((data, key) => {
            if(index === key) {
                name=data.name;
                data.active="active";
            }
            else {
                data.active = null;
            }
        })
        setLists(list);
        if(props.click){
            props.click(name);
        }
     }
    return(
        <div className="sidemenu-container">
            <div className="sidemenu-content">
                <div className="appName">
                    User Portal
                </div>
                <div className="profile">
                    <i className="fa fa-user" style={{fontSize: "80px"}}></i>
                </div>
                <div className="seperator"></div>
                <div className="sidemenu-dashboard">
                <div className="text">Menu List</div>
                <ul className="lists" id="lists">
                    {
                    [...lists].map((data, key) => {
                        return(
                         <li key={key}>
                         <span className="list">{data.name}</span>
                         <div onClick={showSubMenu.bind(this, key)}>
                         <div className="list-content">
                         <span className="icon"><i className={"fa "+ data.icon} ></i></span>
                         <div className="sub-name">
                             {data.sub_name}
                         </div>
                         </div>
                         <ul className="sub-lists">
                             { data.active && [...data.sub_courses].map((subData, i) => {
                                 return(
                                    <li key={i} onClick={(event) => { props.click(event); props.showMap()}} className="sub-list-content">
                                         + {subData.name}
                                     </li>
                                 )
                             }) }
                         </ul>
                         </div>
                         </li>
                        )
                    })
                    }
                </ul>
                </div>
            </div>
            
            <div className="footer">
                
            </div>
        </div>
    )
}

export default AdminSideMenu;