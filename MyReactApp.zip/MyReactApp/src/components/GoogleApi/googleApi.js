import { GoogleComponent } from 'react-google-location' 
import React, { Component } from 'react';
const API_KEY = "Your-Key"  // My Api Key

export class GoogleApi extends Component {
  constructor(props) {
    super(props);
    this.state = { place: '' };
  }
 
  render() {
    return (
      <div>
         <GoogleComponent
          apiKey={API_KEY}
          language={'en'}
          country={'country:in|country:us'}
          coordinates={true}
          placeholder={'Start typing location'}
          onChange={(e) => { this.setState({ place: e }), this.props.change('coordinates',this.state.place) }} />
      </div>

    )
  } 
}
