import React from 'react';
import './showMap.css';
const API_KEY = "Your-key"

class ShowMap extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            company: props.company
        };
        this.getLocation = this.getLocation.bind(this);
        this.getCordinates = this.getCordinates.bind(this);
    }
    getLocation(){
        if(navigator.geolocation){
            navigator.geolocation.getCurrentPosition(this.getCordinates, this.handleLocationError);
        }
        else{
            alert('Geolocation is not supported by this browser');
        }
    }

    getCordinates(position){
        console.log(position);
        this.setState({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
        })
    }

    handleLocationError(error){
        switch(error.code){
            case error.PERMISSION_DENIED: 
                alert("User denied");
                break;
            case error.POSITION_UNAVAILABLE:
                alert('Unavailable');
                break;
            case error.TIMEOUT:
                alert('Timed out');
                break;
            case error.UNKNOWN_ERROR:
                alert("An unknown error occured");
                break;
            default:
                alert("Default unknown error occured");
        }
    }
    
    render(){
        return(
            <div className="showMap" style={this.props.company ? {zIndex: 10}: {zIndex:0}}>
                <h2 onClick={() => this.props.closeMap()}>
                    React maps
                </h2>
                <h4>HTML5 coordinates</h4>
                <div className="map-info">
                <p><b>Latitude: </b> {this.state.company.latitude}</p>
                <p><b>Longitude: </b> {this.state.company.longitude}</p>
                <p><b>Address: </b> {this.state.company.companyAddress}</p>
                </div>
                <h4>Google Maps reverse Geocoding</h4>
                {
                    this.state.company.latitude && this.state.company.longitude ?
                    <img src={`https://maps.googleapis.com/maps/api/staticmap?center=40.714728,-73.998672&zoom=12&size=400x400&key=${API_KEY}`} alt='image'/>:
                    null
                }
            </div>
        )
    }
}

export default ShowMap;