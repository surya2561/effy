import React from 'react';
const Map = (props) => {
    console.log(props.company);
    return(
        <div class="map-container">

        </div>
    )
}

export default Map;