import React, { useEffect, useState } from 'react';
import './header.css';
import AdminSideMenu from '../AdminSideMenu/adminsidemenu';

const header = (props) => {    

    return(
        <div className="header">
            <span>EFFY Company Portal</span>
        </div>
    )
}
export default header;