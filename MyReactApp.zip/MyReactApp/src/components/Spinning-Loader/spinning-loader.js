import React from 'react';
import './spinning-loader.css';
const loader = (props) => {
    return (
        <div className= { "loader " + (props.loader === true ? 'display' : "hide") } >
            <div className="spinner" ></div>
        </div>
    )
}

export default loader;