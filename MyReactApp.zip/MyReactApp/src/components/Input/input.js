import React, { useEffect, useState } from 'react';
import './input.css'
const input = (props) => {
    const [options, setoptions] = useState([]);
    
    useEffect(() => {
        setoptions(props.options);
    },[props.options]);

    let inputElement = null;
    switch(props.input_type){
        case 'input':
            inputElement = <input {...props} onChange={props.change}/>
            break;
        case 'textarea':
            inputElement = <textarea { ...props } onChange={props.change}/>
            break;
        case 'select':
            inputElement = (
            <select name={props.name} id={props.id} onBlur={e => props.change(props.name, e)}>
                {[...options].map((data, key) => {
                    return (<option value={data.id} key={key}>{data.value}</option>);
                })}
            </select>
            );
            break;
        default:
            return;

    }

    return(
        <div className="field">
            <label><b>{props.label}</b></label>
            {inputElement}
        </div>
    )
}

export default input;