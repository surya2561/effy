import React from 'react';
import './backdrop.css';

const BackDrop = (props) => {
    const block = (props.message !== true || props.message !== 'true') && props.message ? 'display' : 'hide';
    return <div className={"backDrop " + block} onClick={props.closeModel}></div>
}

export default BackDrop;