import React from 'react';
import './App.css';
import Loader from '../../components/Spinning-Loader/spinning-loader';
import { subjectService } from '../../services/subject-service';
import Routes from '../../routing';


class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      message: false
    }
  }
  componentDidMount(){
    this.subscription = subjectService.getMessage().subscribe(data => {
      this.setState({
        message: data.message
      })
    })
  }
  closeModel() {
    this.setState({
      message: false
    })
  }
  render() {
    return (
      <div className="App">
        <Loader loader={this.state.message}/>
        <Routes></Routes>
      </div>
    );
  }
  componentWillUnmount(){
    this.subscription.unsubscribe();
  }
}

export default App;
