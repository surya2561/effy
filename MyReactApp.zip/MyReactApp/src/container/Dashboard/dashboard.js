import React from 'react';
import './dashboard.css';
// import { NavLink } from 'react-router-dom';
// import Routes from '../../routing';
import Login from '../login/login';
import Register from '../register/register';
import Header from '../../components/Header/header';
class Dashboard extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            loginComponent: true,
            registerComponent: false
        }
    }
    handleState = (event) => {
    
        if((event.target.innerHTML).toLowerCase() === 'login' || (event.target.innerHTML).toLowerCase() === 'sign in'){
            this.setState({
                loginComponent: true,
                registerComponent: false
            })
        }
        else{
            this.setState({
                loginComponent: false,
                registerComponent: true
            })
        }
    }
    render(){
        return(
            <div >
            <Header />    
            <div className="dashboard">
            <div className="topnav" id="topDiv">
                <div className="nav">
                    <div className={"link login " + (this.state.loginComponent === true ? 'active': null)} onClick={this.handleState.bind(this)}>Login</div>
                    <div className={"link register " + (this.state.registerComponent === true ? 'active': null)} onClick={this.handleState.bind(this)}>Register</div>
                </div>
                <div className="form" >
                    { this.state.loginComponent ? <Login props={this.props}/> : <Register handleState = {this.handleState.bind(this)} type="register"/> }
                </div>
            </div>
            </div>
            </div>
        )
    }
}

export default Dashboard;