import React from 'react';
import AdminSideMenu from '../../../components/AdminSideMenu/adminsidemenu';
import BackDrop from '../../../components/BackDrop/backdrop';
import Header from '../../../components/Header/header';
import Company from '../../company/addCompany/company';
import AdminHome from '../AdminHome/adminhome';
import './admindashboard.css';
import ManageUser from '../ManageUser/manageuser';
import Register from '../../register/register';
import ManageCompany from '../../company/manageCompany/managecompany';
import ShowMap from '../../../components/GoogleApi/ShowMap/showMap';

class AdminDashboard extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            dashboard: true,
            list: [
                { key : 'manage company', value : false, html: 'ManageCompany' },
                { key : 'add company', value : false, html: 'AddCompany' },
                { key : 'add user', value : false, html: 'AddUser' },
                { key : 'manage user', value : false, html: 'ManageUser' },
            ],
            popup: false,
            backdrop: false
        }
    }
    showMenu = () => {
      this.setState({
          showSideMenu: !this.state.showSideMenu
      })
    }
    navigate = (event) => {
        console.log(event); 
        if(event.target){
            let listname = event.target.innerText;
            listname = listname.toLowerCase().trim();
            [...this.state.list].map(data => {
                if(listname.includes(data.key)){
                    data.value = true
                }
                else{
                    data.value = false;
                }
            })
            this.setState({
                dashboard: false,
                list: this.state.list,
                popup: true
            })
        }
        else if(event === 'Home'){

           this.closeModel()
        }
    }
    closeModel(){
        this.setState({
            dashboard: true,
            list: this.state.list,
            popup: false
        })
    }
    enableBackDrop(backdrop) {
        this.setState({
            backdrop: backdrop
        })
    }
    openMap(company){
        console.log(company);
        this.setState({
            map: true,
            company: company
        })
    }
    render() {
        return(
            <div className="admin-dashboard">
            <Header />
            <AdminSideMenu click={this.navigate.bind(this)} showMap={() => this.setState({map: false})}/>
            <div className="admin-container">
            { this.state.dashboard && <AdminHome /> }
            { [...this.state.list].map((data,i) => {
                return (
                    <div className="showComponent" key={i}>
                        {
                        this.state.popup && data.value &&
                        <div className="popup-admin-container">
                            {
                             (data.html==='AddCompany' || data.html === 'AddUser' || this.state.backdrop) ? <BackDrop message="true" closeModel = {this.closeModel.bind(this)}/> : null 
                            }
                            <div className="popup">
                                {
                                    (data.html === 'AddCompany') ? <Company close={() => this.closeModel()}/> :  
                                    (data.html === 'ManageCompany') ? <ManageCompany close={() => this.closeModel()} backdrop = {this.enableBackDrop.bind(this)} openMap={this.openMap.bind(this)} /> : 
                                    (data.html === 'AddUser') ? <Register close={() => this.closeModel()} type="adduser"/>:
                                    (data.html === 'ManageUser') ? <ManageUser close={() => this.closeModel()} backdrop = {this.enableBackDrop.bind(this)}/>: null
                                }
                            </div>

                            {
                                (this.state.map) ? <ShowMap company={this.state.company} closeMap={() => this.setState({map: false})} />: null
                            }
                            
                        </div>
                        }
                    </div>
                )
            }) }
            </div>
            </div>
        )
    }
}

export default AdminDashboard;