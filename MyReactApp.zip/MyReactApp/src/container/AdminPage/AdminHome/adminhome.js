import axios from 'axios';
import React from 'react';
import environment from '../../../environment';
import './adminhome.css';
const environmentService = new environment();
class AdminHome extends React.Component {
    middleSectionList = [
        { key: 'No:of users', value: 0 },
        { key: 'Total Company', value: 0 }
    ]
    allUsersApi = environmentService.getApi().getUsers;
    allCompanyApi = environmentService.getApi().getCompanies;

    constructor(props) {
        super(props);
        this.state = {
            sectionList: this.middleSectionList
        }
        console.log('constructor home');
    }

    stateChangeList(key, value) {
        [...this.middleSectionList].map((data, i) => {
            if (i === key) {
                data.value = value;
            }
        })
        this.setState({
            sectionList: this.middleSectionList
        })
    }
    componentDidMount() {
        let requestOne = axios.get(this.allUsersApi);
        let requestTwo = axios.get(this.allCompanyApi);
        axios.all([requestOne, requestTwo])
        .then(axios.spread((...responses) => {
            this.stateChangeList(0, responses[0].data.users.length);
            this.stateChangeList(1, responses[1].data.company.length);
        }));
    }
    render() {
        return (
            <div className="admin-dashboard">
                <div className="admin-home">
                    <div className="home-container">
                        <div className="top-section">
                            <div className="top-left-section">
                                <span><i className="fab fa-accusoft"></i></span>
                                <span className="text" style={{fontSize: '20px'}}>Landing Dashboard</span>
                            </div>
                            <div className="top-right-section">

                            </div>
                        </div>
                        <hr />
                        <div className="middle-section">
                            {
                                [...this.middleSectionList].map((data, i) => {
                                    return (
                                        <div className="box" key={i}>
                                            <div className="key">{data.key}</div>
                                            <div className="value">{data.value}</div>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default AdminHome;