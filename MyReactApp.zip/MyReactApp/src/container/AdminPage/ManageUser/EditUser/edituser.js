import React, {Component} from 'react';
import './edituser.css';
import Input from '../../../../components/Input/input';
import MaterialUIPickers from '../../../../components/DateTimePicker/date-time-picker';
import axios from 'axios';
import environment from '../../../../environment';

const environmentService = new environment();
class EditUser extends Component{
    constructor(props){
        super(props);
        this.state ={
            user: props.user,
            companies: {}
        };
    }
    
    inputChangeHandler = (fieldName, event) => {
        let fields = this.state.user;
        fields[fieldName] =  event.target ? event.target.value : event;
        this.setState({fields});
    }
    
    submitForm = () => {
        axios.put(environmentService.getApi().updateUser, this.state.user)
        .then(() => {
            this.props.close();
            this.props.update();
        })
    }
    componentDidMount(){
        axios.get(environmentService.getApi().getCompanies)
        .then(success => {
            [...success.data.company].map(data => {
                data.value = data.companyName + " " + data.companyAddress;
            })
            this.setState({
                companies: success.data.company
            })
        })
    }

    render(){
        return (
        <div className="edituser">
            <div className="font-text">
            <h1 >Edit User</h1>
            <i className="fa fa-times" onClick={() => this.props.close()}></i>
            </div>
            <hr/>
            <form autoComplete="off">
             <div className="editUser-container">

              <Input input_type="input" label="FirstName" type="text" placeholder="Enter FirstName" name="firstName" id="firstName" value={this.state.user.firstName} change={this.inputChangeHandler.bind(this, 'firstName')}/>   
             
              <Input input_type="input" label="LastName" type="text" placeholder="Enter LastName" name="lastName" id="lastName" value={this.state.user.lastName} change={this.inputChangeHandler.bind(this, 'lastName')}/>

              <Input input_type="input" label="Email" type="email" placeholder="Enter Email" name="email" id="email" value={this.state.user.email} change={this.inputChangeHandler.bind(this, 'email')}/>
             
              {/* <Input input_type="input" label="Password" type="password" placeholder="Enter Password" name="password" id="psw" value={} change={this.inputChangeHandler.bind(this, 'password')}/> */}
              <Input input_type="select" label="Select Company" placeholder="Select Company" name="company_id" id="company_id" options={this.state.companies} change={this.inputChangeHandler.bind(this)}/>

              <Input input_type="input" label="Designation" type="text" placeholder="Enter Designation" name="designation" id="designation" value={this.state.user.designation} change={this.inputChangeHandler.bind(this, 'designation')}/>

             
              <div className="field">
              <div className="date">
                  <MaterialUIPickers label="Date Of Birth" name="DateOfBirth" inputChangeHandler={this.inputChangeHandler.bind(this, 'dateOfBirth')} value={this.state.user.dateOfBirth} date={new Date()}/>
              </div>
              </div>
           </div>
           <button type="button" className="registerbtn" onClick={this.submitForm.bind(this)}>Update User</button>

         </form>
            </div>
        )
    }
}

export default EditUser;