import Axios from 'axios';
import React, { Component } from 'react';
import axios from 'axios';
import environment from '../../../environment';
import UserPagination from '../../../components/Pagination/user-pagination';
import './manageuser.css';
import BackDrop from '../../../components/BackDrop/backdrop';
import EditUser from './EditUser/edituser';
import './manageuser.css';

const environmentService = new environment();

class ManageUser extends Component{
    constructor(props){
        super(props);
        this.state = {
            users: {},
            popup: false,
            selectUser: {},
            update: false
        }
    }
    fetchData = () => {
        axios.get(environmentService.getApi().getUsers).then(success => {
           this.setState({
                users: success.data.users
            })
        })
    }
    componentDidMount(){
     this.fetchData();
    }

    openPopUp = (user) => {
        this.setState({
            popup: true,
            selectUser: user
        })
        this.props.backdrop(true);
    }

    render(){
        return (
            <div className="manageuser-container">
                <div className="manageuser-content">
                    <div className={this.state.popup ? 'opacity': null}>
                        <UserPagination users={this.state.users} openPopUp={this.openPopUp.bind(this)} update = {() => this.fetchData()}/>
                    </div>
                    </div>
                    {
                        this.state.popup &&
                        <div className="">
                        <div className="popup-container" >
                            <EditUser user={this.state.selectUser} close={() => { this.setState({popup:false}); this.props.backdrop(false) }} update = {() => this.fetchData()}/>
                        </div>
                        </div>
                    }
                </div>
        )
    }
}

export default ManageUser;