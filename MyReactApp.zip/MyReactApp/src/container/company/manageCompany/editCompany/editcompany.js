import React, { Component } from 'react';
import './editcompany.css';
import axios from 'axios';
import environment from '../../../../environment';
import Input from '../../../../components/Input/input';
import { GoogleApi } from '../../../../components/GoogleApi/googleApi';

const environmentService = new environment();
class EditCompany extends Component{
    constructor(props){
        super(props);
        this.state = {
            company: props.company
        }
        console.log(props.company);
    }
    inputChangeHandler = (fieldName, event) => {
        let fields = this.state.company;
        if(fieldName !== 'coordinates'){
            fields[fieldName] = (event && event.target) ? event.target.value : null;
        }
        else{
            fields['latitude'] = "80.3"; //event.coordinates.lat
            fields['longitude'] = "40.5";
            fields['companyAddress'] = event['place']
        }
        this.setState({fields});
    }
    submitForm = () => {
        axios.put(environmentService.getApi().updateCompany, this.state.company)
        .then(() => {
            this.props.close();
            this.props.update();
        })
    }
    render(){
        return(
            <div className="editcompany">
                <div className="font-text">
                <h1 >Edit Company</h1>
                <i className="fa fa-times" onClick={() => this.props.close()}></i>
                </div>
                <hr/>
                <form autoComplete="off">
                    <div className="editcompany-container">
                    <Input input_type="input" label="CompanyName" type="text" placeholder="Enter CompanyName" name="companyName" id="companyName" value={this.state.company.companyName} change={this.inputChangeHandler.bind(this, 'companyName')}/>
                    <GoogleApi change={this.inputChangeHandler.bind(this)}/>
                    {/* <Input input_type="input" label="CompanyAddress" type="text" placeholder="Enter CompanyAddress" name="companyAddress" id="companyAddress" value={this.state.company.companyAddress} change={this.inputChangeHandler.bind(this, 'companyAddress')}/> */}
                    <button type="button" className="registerbtn" onClick={this.submitForm.bind(this)}>Update Company</button>

                    </div>
                </form>    
            </div>
        )
    }
}

export default EditCompany;