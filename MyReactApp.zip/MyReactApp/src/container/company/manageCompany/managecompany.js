import React, { Component } from 'react';
import './managecompany.css';
import axios from 'axios';
import environment from '../../../environment';
import CompanyPagination from '../../../components/Pagination/CompanyPagination/company-pagination';
import EditCompany from './editCompany/editcompany';

const environmentService = new environment();

class ManageCompany extends Component{
    constructor(props){
        super(props);
        this.state = {
            company: {}
        }
    }

    fetchCompanyData(){
        axios.get(environmentService.getApi().getCompanies)
        .then(success => {
            this.setState({
                company: success.data.company
            })
        })
    }
    componentDidMount(){
        this.fetchCompanyData();
    }

    openPopUp = (company) => {
        this.setState({
            popup: true,
            selectCompany: company
        })
        this.props.backdrop(true);
    }


    render(){
        return(
        <div className="managecompany-container">
            <div className="managecompany-content">
                <div className={this.state.popup ? 'opacity': null}>
                <CompanyPagination company={this.state.company} openPopUp={this.openPopUp.bind(this)} update = {() => this.fetchCompanyData()} openMap={(e) => this.props.openMap(e)} />
                </div>
            </div>
            {
                this.state.popup &&
                <div className="">
                <div className="popup-container" >
                    <EditCompany company={this.state.selectCompany} close={() => { this.setState({popup:false}); this.props.backdrop(false) }} update = {() => this.fetchCompanyData()}/>
                </div>
                </div>
            }
            
        </div>
        )
    }
}

export default ManageCompany;