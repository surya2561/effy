import React, { Component } from 'react';
import { GoogleApi } from '../../../components/GoogleApi/googleApi';
import Input from '../../../components/Input/input';
import './company.css';
import axios from 'axios';
import environment from '../../../environment';
const environmentService = new environment();
class Company extends Component{
    constructor(props){
        super(props);
        this.state = {
            fields: {}
        }
    }
    inputChangeHandler = (fieldName, event) => {
        let fields = this.state.fields;
        if(fieldName !== 'coordinates'){
            fields[fieldName] = (event && event.target) ? event.target.value : null;
        }
        else{
            fields['latitude'] = "40.3"; //event.coordinates.lat
            fields['longitude'] = "40.5";
            fields['companyAddress'] = event['place']
        }
        this.setState({fields});
    }
    submitCompanyForm = () => {
        axios.post(environmentService.getApi().saveCompany, this.state.fields)
        .then(success => {
            alert(success.data.msg);
            this.props.close();
        })
    }
    render(){
        return(
            <div className="company-container">
                <div className="company-form">
                <div className="font-text">
                <h1 >Company</h1>
                <i className="fa fa-times" onClick={() => this.props.close()}></i>
                </div>
                <hr/>
                <form autoComplete="off">
                <Input input_type="input" label="Company Name" type="text" placeholder="Enter CompanyName" name="companyName" id="companyName" change={this.inputChangeHandler.bind(this, 'companyName')}/>   
                <div className="fieldName">Company Address </div>
                <GoogleApi change={this.inputChangeHandler.bind(this)}/>
                <button type="button" className="button" onClick={this.submitCompanyForm.bind(this)}>Submit</button>
                </form>
                </div>
            </div>
        )
    }
}
export default Company;
