import React, { Component } from 'react';
import './register.css';
import axios from 'axios'
import environment from '../../environment';
import Input from '../../components/Input/input';
import MaterialUIPickers from '../../components/DateTimePicker/date-time-picker';
const environmentService = new environment();
class Register extends Component {
    email_regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    constructor(props){
        super(props);
        this.state = {
            fields: {},
            companies: {},
            errors: {}
        }
        this.inputChangeHandler = this.inputChangeHandler.bind(this);
    }
  
    inputChangeHandler = (fieldName, event) => {
        let fields = this.state.fields;
        fields[fieldName] =  (fieldName !== 'DateOfBirth' ? event.target.value : event);
        this.setState({fields});
    }

    handleValidation = () => {
        const obj = this.state.fields;
        let formIsValid = true;
        let errors = {};
        if(!obj.firstName){
            formIsValid = false;
            errors['nameErrorMessage'] = 'Field cannot be empty';
        }
        else{
            errors['nameErrorMessage'] = null;
        }

        if(!obj.email || !obj.email.match(this.email_regex)){
            formIsValid = false;
            errors['emailErrorMessage'] = 'Invalid mail'
        }
        else{
            errors['emailErrorMessage'] = null
        }

        if(!obj.password){
            formIsValid = false;
            errors['passwordErrorMessage'] = 'Invalid Password'
        }
        else{
            errors['passwordErrorMessage'] = null
        }

        if(this.props.type !== 'adduser' && (!document.getElementById('psw').value || document.getElementById('psw').value !== document.getElementById('psw-repeat').value)){
            formIsValid = false;
            errors['confirmPasswordErrorMessage'] = 'Password Doesnot match'
        }
        else{
            errors['confirmPasswordErrorMessage'] = null
        }

        this.setState({errors: errors});
        return formIsValid;
    }

    submitForm = (event) => {
        if(this.handleValidation()){
            axios({
                url: environmentService.getApi().registerApi,
                method: 'POST',
                data: this.state.fields,
            })
            .then(success => {
                alert(success.data.msg);
            })
        }
        event.preventDefault();
    }

    componentDidMount(){
        axios.get(environmentService.getApi().getCompanies)
        .then(success => {
            [...success.data.company].map(data => {
                data.value = data.companyName + " " + data.companyAddress;
            })
            this.setState({
                companies: success.data.company
            })
        })
    }

    render(){
        return(
            <div className={ this.props.type === 'adduser' ? 'adduserform': "register-form" }>
            <div className="register">
            <form autoComplete="off">
                  
                  <div className="container">
                  <div className="font-text">
                  <h1>{String(this.props.type).toLocaleUpperCase()}</h1>
                  {
                      this.props.type === 'adduser' &&
                  <i className="fa fa-times" onClick={() => this.props.close()}></i>
                  }
                  </div>
                  <p>Please fill in this form to add a user.</p>
                  <hr/>

                  <Input input_type="input" label="FirstName" type="text" placeholder="Enter FirstName" name="firstName" id="firstName" change={this.inputChangeHandler.bind(this, 'firstName')}/>   
                  <p className="error">{this.state.errors.nameErrorMessage }</p>

                  <Input input_type="input" label="LastName" type="text" placeholder="Enter LastName" name="lastName" id="lastName" change={this.inputChangeHandler.bind(this, 'lastName')}/>

                  <Input input_type="input" label="Email" type="email" placeholder="Enter Email" name="email" id="email" change={this.inputChangeHandler.bind(this, 'email')}/>
                  <p className="error">{this.state.errors.emailErrorMessage }</p>

                  <Input input_type="input" label="Password" type="password" placeholder="Enter Password" name="password" id="psw" change={this.inputChangeHandler.bind(this, 'password')}/>
                  <p className="error">{this.state.errors.passwordErrorMessage }</p>
                  
                  {
                      this.props.type !== 'adduser' &&
                      <div>
                        <Input input_type="input" label="Repeat Password" type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat"/>
                        <p className="error">{this.state.errors.confirmPasswordErrorMessage  }</p>
                    </div>
                  }

                  <Input input_type="select" label="Select Company" placeholder="Select Company" name="company_id" id="company_id" options={this.state.companies} change={this.inputChangeHandler.bind(this)}/>

                  <Input input_type="input" label="Designation" type="text" placeholder="Enter Designation" name="designation" id="designation" change={this.inputChangeHandler.bind(this, 'designation')}/>

                 <div className="field">
                  <div className="date">
                     <MaterialUIPickers label="Date Of Birth" name="DateOfBirth" inputChangeHandler={this.inputChangeHandler.bind(this, 'DateOfBirth')} date={new Date()}/>
                  </div>
                  </div>

                  <p className="error">{this.state.errors.responseError}</p>

                  <hr/>
                  <button type="button" className="registerbtn" onClick={this.submitForm.bind(this)}>{ this.props.type === 'adduser' ? <span>Add User</span> : <span>Register</span> }</button>
                  </div>
                  {
                    this.props.type !== 'adduser' &&
                  <div className="signin">
                  <span className="span">Already have an account? <div className="text"  onClick={this.props.handleState.bind(this)}>Sign in</div>.</span>
                  </div>
                  }
            </form>
            </div>
            </div>
        )
    }
}

export default Register;