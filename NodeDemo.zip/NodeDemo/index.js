const express = require('express');
const app = express();
const createError = require('http-errors');
const user = require('./Controllers/User');
const company = require('./Controllers/Company');
require('dotenv').config();
require('./Delegates/DBConnection');

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-with,Authorization, Content-Type, Accept');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    next();
})
app.use('/api/effy/users', user);
app.use('/api/effy/company', company);

app.use(async(req, res, next) => {
    next(createError.NotFound());
})
app.use((err, req, res, next) => {
    let status = err.status || 500;
    res.status(status).send({ err});
})

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
    console.log(`Server listening at port ${PORT}`);
})