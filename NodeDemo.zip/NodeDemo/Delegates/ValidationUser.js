const Joi = require('joi');

const ValidationUserRegisterSchema = Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().lowercase().required(),
    password: Joi.string().required().min(6),
    designation: Joi.string().required(),
    DateOfBirth: Joi.date().iso().required(),
    company_id: Joi.number()
})

const ValidationUserLoginSchema = Joi.object({
    email: Joi.string().email().lowercase().required(),
    password: Joi.string().required()
})

module.exports = { ValidationUserRegisterSchema, ValidationUserLoginSchema }