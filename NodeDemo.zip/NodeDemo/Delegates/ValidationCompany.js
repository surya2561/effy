const Joi = require('joi');
const ValidationCompanySchema = Joi.object({
    companyName: Joi.string().required(),
    companyAddress: Joi.string().required(),
    latitude: Joi.string().required(),
    longitude: Joi.string().required()
})

module.exports = { ValidationCompanySchema };