const jwt = require('jsonwebtoken');
const createError = require('http-errors');
require('dotenv').config()
module.exports = {
    signAccessToken: (userId) => {
        return new Promise((resolve, reject) => {
            const payload = {
                date: new Date()
            };
            const options = {
                expiresIn: '1hr',
                issuer: 'effy.com',
                audience: String(userId)
            }
            jwt.sign(payload, process.env.JWT_SECRET_KEY, options, (err, token) => {
                if(err) return reject(err);
                resolve(token);
            })
        })
    },
    verifyToken: (req, res, next) => {
        if(!req.headers['authorization']) return next(createError.NotFound('Token is not found'));
        const token = req.headers['authorization'].split(' ')[1];
        jwt.verify(token, process.env.JWT_SECRET_KEY, (err, payload) => {
            if(err){
                if(err.name === 'JsonWebTokenError'){
                    return next(createError.Unauthorized());
                }
                else{
                    return next(createError.Unauthorized(err.message));
                }
            }
            next();
        })
    }
}