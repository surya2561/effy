const bcrypt = require('bcrypt');

const encryptPassword = async(password) => {
    try {
        const salt = await bcrypt.genSalt(10);
        const hashPassword = await bcrypt.hash(password, salt);
        return hashPassword;
    } catch (error) {
        throw new Error(error);
    }
}

const decryptPassword = async(hashPassword, password) => {
    try {

        return await bcrypt.compare(password, hashPassword)
    } catch (error) {
         throw new Error(error)
    }
}

module.exports = { encryptPassword, decryptPassword };