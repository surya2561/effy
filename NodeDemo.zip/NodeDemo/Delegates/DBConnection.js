const mysql = require('mysql2');
require('dotenv').config();
const mysqlDBConnection = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'Suri@1134',
    database: 'effy'
})
.promise()

module.exports = { mysqlDBConnection };