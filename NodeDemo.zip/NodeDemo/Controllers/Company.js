const express = require('express');
const { verifyToken } = require('../Delegates/JsonWebToken');
const { ValidationCompanySchema } = require('../Delegates/ValidationCompany');
const createError = require('http-errors');
const Company = require('../Models/Company')
const router = express.Router();

router.post('/saveCompany', [verifyToken], async(req, res, next) => {
    try {
        const result = await ValidationCompanySchema.validateAsync(req.body);
        const company = new Company(result);
        const [saveCompany] = await company.saveCompany();
        if(saveCompany){
            res.status(200).send({msg: 'Company Added Successfully'});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})

router.get('/getCompanies',  async(req, res, next) => {
    try {
        const [getCompanies] = await Company.getCompanies();
        if(getCompanies) res.status(200).send({company: getCompanies});
        else throw createError[500];
    } catch (error) {
        next(error);
    }
})

router.get('/getCompany/:id', [verifyToken], async(req, res, next) => {
    try {
        const [getCompany] = await Company.getCompanyById(req.params.id);
        if(getCompany) res.status(200).send({ company: getCompany});
        else throw createError[500];
    } catch (error) {
        next(error);
    }
})

router.put('/updateCompany', [verifyToken], async(req, res, next) => {
    try {
        const [updateCompany] = await Company.updateCompany(req.body);
        if(updateCompany) res.status(200).send({ msg: 'Company details gets updated' });
        else throw createError[500];
    } catch (error) {
        next(error);
    }
})

router.delete('/deleteCompany', [verifyToken], async(req, res, next) => {
    try {
        const [deleteCompany] = await Company.deleteCompany(req.query.id);
        if(deleteCompany) res.status(200).send({msg: 'Company gets deleted'});
        else throw createError[500];
    } catch (error) {
        next(error);
    }
})

module.exports = router;