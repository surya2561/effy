const express = require('express');
const router = express.Router();
const validatingSchema = require('../Delegates/ValidationUser');
const createError = require('http-errors');
const User = require('../Models/User');
const encryptDecryptPassword = require('../Delegates/EncryptDecryptPassword');
const jwtToken = require('../Delegates/JsonWebToken');
const { verifyToken } = require('../Delegates/JsonWebToken');

router.post('/register', async(req, res, next) => {
    try {
        req.body.company_id = parseInt(req.body.company_id);
        const result = await validatingSchema.ValidationUserRegisterSchema.validateAsync(req.body);
        const [doesExist] = await User.checkUser(result.email);
        if(doesExist && doesExist.length) throw createError.Conflict(`${result.email} is already exists`);
        result.password = await encryptDecryptPassword.encryptPassword(result.password);
        const user = new User(result);
        const [saveUser] = await user.saveUser(result);
        if(saveUser) res.status(200).send({msg: "User saved Successfully"});
        else throw createError[500]
    } catch (error) {
        if(error.isJoi === true){
            error.status = 422;
        }
        next(error);
    }
})

router.post('/login', async(req, res, next) => {
    try {
        const result = await validatingSchema.ValidationUserLoginSchema.validateAsync(req.body);
        const [[checkUser]] = await User.checkUser(result.email);
        if(!checkUser) throw createError.Conflict(`${result.email} is not registered`);
        const checkPassword = await encryptDecryptPassword.decryptPassword(checkUser.password, result.password);
        if(!checkPassword) throw createError.NotFound('User id or Password is invalid');
        const token = await jwtToken.signAccessToken(checkUser.id);
        res.status(200).send({ token: token});
        
    } catch (error) {
        if(error.isJoi === true){
            error.status = 422;
            error = {message: error.message} 
        }
        next(error)
    }
})

router.get('/listUsers', [verifyToken], async(req, res, next) => {
    try {
        const [getUsers] = await User.getAllUsers();
        res.status(200).send({users: getUsers});
    } catch (error) {
        next(error);
    }
})

router.get('/getUser/:id', [verifyToken], async(req, res, next) => {
    try {
        const [getUser] = await User.getUserById(req.params.id);
        res.status(200).send({user: getUser});
    } catch (error) {
        next(error);
    }
})

router.put('/updateUser', [verifyToken], async(req, res, next) => {
    try {
        req.body.dateOfBirth = new Date(req.body.dateOfBirth);
        const [updateUser] = await User.updateUser(req.body);
        if(updateUser){
            res.status(200).send({msg : 'User Updated'});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})

router.put('/deactivateUser', [verifyToken], async(req,res, next) => {
    try {
        const [deactivateUser] = await User.deactivateUser(req.body.id, req.body.active);
        if(deactivateUser){
            res.status(200).send({msg : 'User Deactivated'});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error)
    }
})

router.delete('/deleteUser', [verifyToken], async(req, res, next) =>{
    try {
        const [deleteUser] = await User.deleteUser(req.query.id);
        if(deleteUser){
            res.status(200).send({msg: 'User Deleted Successfully'});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})

router.get('/getUserCompany/:companyId', [verifyToken], async(req, res, next) => {
    try {
        const [getUserCompany] = await User.getUserCompany(req.params.companyId);
        if(getUserCompany){
            res.status(200).send({ user: getUserCompany});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})


router.get('/getUserByCompanyId/:companyId', [verifyToken], async(req, res, next) => {
    try {
        const [getUser] = await User.getUserByCompanyId(req.params.companyId);
        if(getUser){
            res.status(200).send({user: getUser});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})

router.put('/removeUserCompany/:id', [verifyToken], async(req, res, next) => {
    try {
        const [removeUser] = await User.removeUserCompany(req.params.id);
        if(removeUser){
            res.status(200).send({ msg: `User Removed from the company`});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})

router.put('/updateUserCompany', [verifyToken], async(req, res, next) => {
    try {
        const [updateUserCompany] = await User.updateUserCompany(req.body.companyId, req.body.id);
        if(updateUserCompany){
            res.status(200).send({ msg: 'User company gets updated'});
        }
        else{
            throw createError[500];
        }
    } catch (error) {
        next(error);
    }
})
module.exports = router;