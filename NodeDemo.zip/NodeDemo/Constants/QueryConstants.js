const queryConstants = () => {
    const users = {
        CHECK_USER : 'SELECT * FROM USERS WHERE email = ? AND active = 1',
        SAVE_USER: 'INSERT INTO USERS(firstName, lastName, email, password, designation, dateOfBirth, company_id) VALUE (?,?,?,?,?,?,?)',
        GET_ALL_USERS : 'SELECT USERS.id, USERS.firstName, USERS.lastName, USERS.email, USERS.dateOfBirth, USERS.designation, USERS.active, COMPANY.companyName FROM USERS INNER JOIN COMPANY ON USERS.company_id = COMPANY.id',
        GET_USER_BY_ID: 'SELECT id, firstName, lastName, email, dateOfBirth, designation FROM USERS WHERE id = ? AND active = 1',
        UPDATE_USER: 'UPDATE USERS SET firstName = ?, lastName = ?, email = ?, designation = ?, dateOfBirth = ?, company_id = ?  WHERE id = ? AND active = 1',
        DEACTIVATE: 'UPDATE USERS SET active = ? WHERE id = ?',
        DELETE_USER: 'DELETE FROM USERS WHERE id = ?',
        DELETE_USER_COMPANY: 'UPDATE USERS SET company_id = ? WHERE id = ?',
        GET_USER_COMPANY: 'SELECT id, firstName, lastName, email, dateOfBirth, designation FROM USERS INNER JOIN COMPANY ON USERS.company_id = COMPANY.id AND USERS.company_id = ?',
        GET_USER_BY_COMPANYID: 'SELECT id, firstName, lastName, email, dateOfBirth, designation FROM USERS WHERE company_id = ?',
        REMOVE_USER_COMPANY: 'UPDATE USERS SET company_id = 0 WHERE id = ?',
        UPDATE_USER_COMPANY: 'UPDATE USERS SET company_id = ? WHERE id = ?',
    }
    const company = {
        SAVE_COMPANY : 'INSERT INTO COMPANY(companyName, companyAddress, latitude, longitude) VALUES(?,?,?,?)',
        // GET_COMPANIES : 'SELECT * FROM COMPANY',
        GET_COMPANY_BY_ID: 'SELECT * FROM COMPANY WHERE id = ?',
        UPDATE_COMPANY: 'UPDATE COMPANY SET companyName = ? , companyAddress = ?, latitude = ?, longitude = ? WHERE id = ?',
        DELETE_COMPANY: 'DELETE FROM COMPANY WHERE id = ?',
        GET_COMPANIES : 'SELECT COMPANY.companyName, COMPANY.companyAddress, COMPANY.id, COMPANY.latitude, COMPANY.longitude,COUNT(USERS.id) AS user_count FROM COMPANY LEFT JOIN USERS ON USERS.company_id = COMPANY.id GROUP BY 1'
    }
    return { users, company }
}

module.exports = { queryConstants }