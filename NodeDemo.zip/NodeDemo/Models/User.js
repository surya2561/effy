const dbConn = require('../Delegates/DBConnection').mysqlDBConnection;
const query = require('../Constants/QueryConstants').queryConstants();
class User{
    constructor(user){
        this.user = user;
    }
    saveUser(user){
        return dbConn.execute(query.users.SAVE_USER, [
            user.firstName,
            user.lastName,
            user.email,
            user.password,
            user.designation,
            user.DateOfBirth,
            user.company_id
        ])
    }
    static checkUser(email) {
        return dbConn.execute(query.users.CHECK_USER, [email]);
    }
    static getAllUsers(){
        return dbConn.execute(query.users.GET_ALL_USERS);
    }
    static getUserById(id){
        return dbConn.execute(query.users.GET_USER_BY_ID, [id]);
    }
    static updateUser(user){
        return dbConn.execute(query.users.UPDATE_USER, [user.firstName, user.lastName, user.email, user.designation, user.dateOfBirth, user.company_id, user.id]);
    }
    static deactivateUser(id, active){
        return dbConn.execute(query.users.DEACTIVATE, [active, id]);
    }
    static deleteUser(id){
        return dbConn.execute(query.users.DELETE_USER, [id]);
    }
    static getUserCompany(company_id){
        return dbConn.execute(query.users.GET_USER_BY_COMPANYID, [company_id]);
    }
    static getUserByCompanyId(company_id){
        return dbConn.execute(query.users.GET_USER_BY_COMPANYID, [company_id]);
    }
    static removeUserCompany(id){
        return dbConn.execute(query.users.REMOVE_USER_COMPANY, [id]);
    }
    static updateUserCompany(company_id,id){
        return dbConn.execute(query.users.UPDATE_USER_COMPANY, [company_id, id]);
    }
}

module.exports = User;