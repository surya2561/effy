const dbConn = require('../Delegates/DBConnection').mysqlDBConnection;
const query = require('../Constants/QueryConstants').queryConstants();

class Company{
    constructor(company){
        this.company = company
    }
    saveCompany(){
        return dbConn.execute(query.company.SAVE_COMPANY, [
            this.company.companyName,
            this.company.companyAddress,
            this.company.latitude,
            this.company.longitude
        ])
    }
    static getCompanies(){
        return dbConn.execute(query.company.GET_COMPANIES);
    }
    static getCompanyById(id){
        return dbConn.execute(query.company.GET_COMPANY_BY_ID, [id]);
    }
    static updateCompany(company){
        return dbConn.execute(query.company.UPDATE_COMPANY, [company.companyName,company.companyAddress, company.latitude, company.longitude, company.id]);
    }
    static deleteCompany(id){
        return dbConn.execute(query.company.DELETE_COMPANY, [id]);
    }
}
module.exports = Company